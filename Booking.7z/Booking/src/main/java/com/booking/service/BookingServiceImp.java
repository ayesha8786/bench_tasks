/*
 * package com.booking.service;
 * 
 * import java.util.List; import java.util.Optional;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service;
 * 
 * import com.booking.entity.Booking; import
 * com.booking.repsitory.BookingRepository;
 * 
 * @Service public class BookingServiceImp implements BookingService {
 * 
 * @Autowired(required = true) private BookingRepository bookRepo;
 * 
 * @Override public Booking addBook(Booking book) { return
 * bookRepo.insert(book); }
 * 
 * @Override public Booking updateBook(Booking book) { return
 * bookRepo.save(book); }
 * 
 * @Override public String deleteBook(String id) { bookRepo.deleteById(id);
 * return id; } // // @Override // public Optional<Booking> getBook(int
 * parseInt) { // // TODO Auto-generated method stub // return null; // }
 * 
 * @Override public List<Booking> findAll() { return bookRepo.findAll(); }
 * 
 * }
 */