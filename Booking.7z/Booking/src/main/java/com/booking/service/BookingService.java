//package com.booking.service;
//
//import java.util.List;
//import java.util.Optional;
//
//import com.booking.entity.Booking;
//
//public interface BookingService {
//
//	Booking addBook(Booking book);
//
//	Booking updateBook(Booking book);
//
////	Optional<Booking> getBook(String id);
//
//	String deleteBook(String id);
//
//	
//	List<Booking> findAll();
//
//	
//
//
//
//
//
//
//}
